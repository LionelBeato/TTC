function foo() {
  var bar;
  function zip(){
     var quux = 5;
     bar = true;
  }

    quux = 6;
     return zip;

}
